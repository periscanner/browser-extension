(function(){const T="https://fibjnghzdogyhjzubokf.supabase.co/storage/v1/object/public/periscanner/clusters/periscanner_logo.png",k="http://localhost:8787/api";async function A(e){const t=await fetch(`${k}/extension/scan`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({urlTokenAddress:e})});if(!t.ok){const n=await t.json().catch(()=>({}));throw new Error(n.error||"Failed to scan pair")}return await t.json()}async function C(e){const t=await fetch(`${k}/cluster/by-wallets`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({wallets:e})});if(!t.ok)throw new Error("Failed to fetch clusters");return await t.json()}async function E(e){const t=await fetch(`${k}/wallet/ingest-bulk`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({wallets:e})});if(!t.ok)throw new Error("Failed to ingest wallets");return await t.json()}function M(){const e=window.location.pathname,t=/[1-9A-HJ-NP-Za-km-z]{32,44}/,n=e.match(t);if(n)return console.log("[Cluster Scanner] Found address in path:",n[0]),n[0];const s=document.querySelector('iframe[src*="tokenAddress="]');if(s){const a=s.getAttribute("src");if(a){const r=a.match(/tokenAddress=([^&]+)/);if(r)return console.log("[Cluster Scanner] Found token in iframe:",r[1]),r[1]}}return null}function S(e,t=2){return e>=1e9?`${(e/1e9).toFixed(t)}B`:e>=1e6?`${(e/1e6).toFixed(t)}M`:e>=1e3?`${(e/1e3).toFixed(t)}K`:e.toFixed(t)}function y(e,t){return`${(e/t*100).toFixed(2)}%`}function $(e,t){let n=!1,s=!1,a=0,r=0,l=0,i=0;t.addEventListener("pointerdown",h);function h(c){c.preventDefault(),t.setPointerCapture(c.pointerId);const d=e.getBoundingClientRect();e.style.bottom="auto",e.style.right="auto",e.style.left=`${d.left}px`,e.style.top=`${d.top}px`,a=c.clientX,r=c.clientY,l=d.left,i=d.top,n=!0,s=!1,t.addEventListener("pointermove",g),t.addEventListener("pointerup",f),t.addEventListener("pointercancel",f)}function g(c){if(!n)return;const d=c.clientX-a,m=c.clientY-r;(Math.abs(d)>3||Math.abs(m)>3)&&(s=!0);let x=l+d,o=i+m;const u=window.innerWidth-e.offsetWidth,b=window.innerHeight-e.offsetHeight;x=Math.max(0,Math.min(x,u)),o=Math.max(0,Math.min(o,b)),e.style.left=`${x}px`,e.style.top=`${o}px`}function f(c){n&&(n=!1,t.hasPointerCapture(c.pointerId)&&t.releasePointerCapture(c.pointerId),t.removeEventListener("pointermove",g),t.removeEventListener("pointerup",f),t.removeEventListener("pointercancel",f),setTimeout(()=>{s=!1},100))}return{wasDragging:()=>s}}function H(){const e=document.createElement("style");e.textContent=`
    #cluster-scanner-widget {
      position: fixed; 
      bottom: 20px;
      right: 20px;
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      touch-action: none;
      user-select: none; 
    }

    .cs-toggle {
      width: 56px;
      height: 56px;
      background: #1e293b;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: grab;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
      transition: transform 0.1s;
      border: 2px solid #334155;
      padding: 0;
      overflow: hidden;
    }

    .cs-toggle:active {
      cursor: grabbing;
      transform: scale(0.95);
    }

    .cs-toggle img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      pointer-events: none;
    }

    .cs-panel {
      position: absolute;
      bottom: 70px;
      right: 0;
      width: 420px;
      max-height: 600px;
      background: rgba(15, 23, 42, 0.9);
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
      display: none;
      flex-direction: column;
      border: 1px solid #1e293b;
      backdrop-filter: blur(8px);
    }

    .cs-panel.visible { display: flex; }

    .cs-header {
      padding: 16px;
      background: #1e293b;
      border-bottom: 1px solid #334155;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .cs-header h3 { margin: 0; color: #60a5fa; font-size: 16px; font-weight: 600; }
    
    .cs-close {
      background: none; border: none; color: #94a3b8; font-size: 24px; cursor: pointer;
    }
    .cs-close:hover { color: white; }

    .cs-stats {
      padding: 12px 16px;
      background: rgba(30, 41, 59, 0.5);
      border-bottom: 1px solid #334155;
      font-size: 11px;
      color: #94a3b8;
    }

    .cs-stats-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 4px;
    }

    .cs-stats-label { color: #64748b; }
    .cs-stats-value { color: #e2e8f0; font-weight: 500; }

    .cs-content { flex: 1; overflow-y: auto; padding: 16px; color: #e2e8f0; max-height: 400px; }
    
    .cs-loading { padding: 20px; text-align: center; color: #94a3b8; }
    .cs-error { background: #450a0a; color: #fca5a5; padding: 10px; border-radius: 6px; font-size: 13px; }
    .cs-empty { text-align: center; color: #64748b; padding: 20px; }
    
    .cs-cluster { 
      margin-bottom: 12px; 
      background: rgba(30, 41, 59, 0.3); 
      border-radius: 8px; 
      padding: 10px; 
      border: 1px solid #334155; 
    }
    
    .cs-cluster-header { 
      display: flex; 
      justify-content: space-between; 
      align-items: center;
      margin-bottom: 8px; 
    }
    
    .cs-cluster-name { 
      font-weight: bold; 
      color: #93c5fd; 
      font-size: 13px; 
    }
    
    .cs-cluster-total {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      font-size: 10px;
    }
    
    .cs-cluster-amount {
      color: #fbbf24;
      font-weight: 600;
      font-size: 9px;
    }
    
    .cs-cluster-percentage {
      color: #10b981;
      font-size: 14px;
    }
    
    .cs-member { 
      display: flex; 
      justify-content: space-between; 
      align-items: center;
      font-size: 11px; 
      padding: 4px 0; 
      border-bottom: 1px solid rgba(255,255,255,0.05); 
    }
    
    .cs-member:last-child {
      border-bottom: none;
    }
    
    .cs-member-left {
      display: flex;
      align-items: center;
      gap: 4px;
    }
    
    .cs-member-addr { 
      font-family: monospace; 
      color: #94a3b8; 
    }
    
    .cs-member-role { 
      font-size: 9px; 
      color: #64748b; 
      background: rgba(100, 116, 139, 0.2);
      padding: 2px 6px;
      border-radius: 4px;
    }
    
    .cs-member-right {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
    }
    
    .cs-member-amount {
      color: #e2e8f0;
      font-size: 11px;
    }
    
    .cs-member-percentage {
      color: #10b981;
      font-size: 9px;
    }
    
    .cs-member-score { 
      font-size: 9px; 
      color: #fbbf24; 
      margin-left: 4px;
    }
    
    .cs-footer {
      padding: 10px;
      display: flex;
      gap: 10px;
      border-top: 1px solid #334155;
    }

    .cs-refresh, .cs-deep-analyze {
      flex: 1;
      padding: 10px; 
      color: white; 
      border: none; 
      border-radius: 6px; 
      cursor: pointer; 
      font-weight: 600;
      font-size: 12px;
      transition: opacity 0.2s;
    }

    .cs-refresh { background: #334155; }
    .cs-deep-analyze { background: #2563eb; }
    
    .cs-refresh:disabled, .cs-deep-analyze:disabled { 
      opacity: 0.5; 
      cursor: not-allowed; 
    }

    .cs-meta { 
      font-size: 10px; 
      color: #64748b; 
      padding: 0 16px 8px; 
      text-align: right; 
    }
  `,document.head.appendChild(e)}function B(){const e=document.createElement("div");return e.id="cluster-scanner-widget",e.innerHTML=`
    <button id="cs-toggle" class="cs-toggle" title="Drag to move, click to toggle">
      <img src="${T}" alt="Scanner" />
    </button>
    <div id="cs-panel" class="cs-panel">
      <div class="cs-header">
        <h3>Cluster Scanner</h3>
        <button id="cs-close" class="cs-close">×</button>
      </div>
      <div id="cs-stats" class="cs-stats"></div>
      <div id="cs-content" class="cs-content">
        <div class="cs-loading">Click Refresh to scan</div>
      </div>
      <div class="cs-footer">
        <button id="cs-refresh" class="cs-refresh">Refresh Scan</button>
        <button id="cs-deep-analyze" class="cs-deep-analyze" title="Analyze unknown top holders">Deep Analyze</button>
      </div>
    </div>
  `,document.body.appendChild(e),{container:e,toggleBtn:e.querySelector("#cs-toggle"),panel:e.querySelector("#cs-panel"),closeBtn:e.querySelector("#cs-close"),stats:e.querySelector("#cs-stats"),content:e.querySelector("#cs-content"),refreshBtn:e.querySelector("#cs-refresh"),deepAnalyzeBtn:e.querySelector("#cs-deep-analyze")}}function R(e,t,n,s){if(t.length===0){e.content.innerHTML='<div class="cs-empty">No shared clusters found among top holders.</div>';return}const a=t.map(r=>`
    <div class="cs-cluster">
      <div class="cs-cluster-header">
        <span class="cs-cluster-name">${r.cluster_name||"Unnamed Cluster"}</span>
        <div class="cs-cluster-total">
          <span class="cs-cluster-amount">${S(r.totalAmount)}</span>
          <span class="cs-cluster-percentage">${y(r.totalAmount,s)}</span>
        </div>
      </div>
      <div>
        ${r.members.map(l=>{const i=n.get(l.wallet_address)||0;return`
            <div class="cs-member">
              <div class="cs-member-left">
                <span class="cs-member-addr">${l.wallet_address.slice(0,4)}...${l.wallet_address.slice(-4)}</span>
                <span class="cs-member-role">${l.role}</span>
              </div>
              <div class="cs-member-right">
                <span class="cs-member-amount">${S(i)}</span>
                <span class="cs-member-percentage">${y(i,s)}</span>
              </div>
            </div>
          `}).join("")}
      </div>
    </div>
  `).join("");e.content.innerHTML=a}const L=new Set(["6EF8rSutb9YvXWvP3NMWH5A7yQW52X4N1CdcS668JAt5","5Q54nC7onSgSJ8Ct37628oP57Fz6Y392S28k8B1R8M99","11111111111111111111111111111111","TokenkegQFEZmcsp366nz8SE69bb376o16Mxn4f8B8"]);async function w(e,t=!1){const n=M();if(!n){e.content.innerHTML='<div class="cs-error">Could not find address in URL. Open a Pair or Token page.</div>';return}e.content.innerHTML='<div class="cs-loading">Resolving Pair & Scanning Holders...</div>',e.refreshBtn.disabled=!0,e.deepAnalyzeBtn.disabled=!0;try{const s=await A(n);console.log("[Cluster Scanner] Scan data:",s);const a=s.holders||[],r=s.stats.totalSupply;if(a.length===0){e.content.innerHTML='<div class="cs-empty">No holders found.</div>';return}const l=a.filter(o=>!L.has(o.owner)),i=o=>{const b=l.slice(0,20).reduce((v,z)=>v+z.humanReadableAmount,0),p=y(b,r);e.stats.innerHTML=`
        <div class="cs-stats-row">
          <span class="cs-stats-label">Total Supply:</span>
          <span class="cs-stats-value">${S(r,0)}</span>
        </div>
        <div class="cs-stats-row">
          <span class="cs-stats-label">Unique Holders:</span>
          <span class="cs-stats-value">${s.totalUniqueHolders.toLocaleString()}</span>
        </div>
        ${o||""}
        <div class="cs-stats-row" title="Excludes LPs and Bonding Curves">
          <span class="cs-stats-label">Top 20 Hold:</span>
          <span class="cs-stats-value">${p}</span>
        </div>
        <div class="cs-stats-row">
          <span class="cs-stats-label">Decimals:</span>
          <span class="cs-stats-value">${s.metadata.decimals}</span>
        </div>
      `};i();const h=a.map(o=>o.owner),g=new Map(a.map(o=>[o.owner,o.humanReadableAmount]));e.content.innerHTML='<div class="cs-loading">Checking known clusters...</div>';let f=await C(h),c=f.clusters||[];if(t){const o=new Set;c.forEach(p=>{p.members.forEach(v=>o.add(v.wallet_address))});const b=a.filter(p=>!o.has(p.owner)&&!L.has(p.owner)).slice(0,10).map(p=>p.owner);if(b.length>0){e.content.innerHTML=`<div class="cs-loading">Analyzing ${b.length} new top holders...</div>`;try{await E(b),e.content.innerHTML='<div class="cs-loading">Refreshing cluster data...</div>',f=await C(h),c=f.clusters||[]}catch(p){console.error("[Cluster Scanner] Ingest error:",p),e.content.insertAdjacentHTML("afterbegin",'<div class="cs-error">Analysis partial failure. Showing existing data.</div>')}}else console.log("[Cluster Scanner] All top holders already analyzed.")}console.log("[Cluster Scanner] Raw clusters:",c);const d=_(c,g),m=new Set;let x=0;if(d.forEach(o=>{o.members.forEach(u=>{m.has(u.wallet_address)||(m.add(u.wallet_address),x+=g.get(u.wallet_address)||0)})}),m.size>0){const o=y(x,r),u=`
        <div class="cs-stats-row" style="color: #60a5fa; font-weight: bold;">
          <span class="cs-stats-label" style="color: #60a5fa;">Periscanner Cluster %:</span>
          <span class="cs-stats-value">${m.size} Wallets Hold: ${o}</span>
        </div>
      `;i(u)}console.log("[Cluster Scanner] Relevant clusters after processing:",d),R(e,d,g,r)}catch(s){console.error("[Cluster Scanner] Error:",s),e.content.innerHTML=`<div class="cs-error">${s instanceof Error?s.message:"Unknown Error"}</div>`}finally{e.refreshBtn.disabled=!1,e.deepAnalyzeBtn.disabled=!1}}function _(e,t){return e.map(n=>{const s=Array.isArray(n.members)?n.members:[],a=s.filter(l=>t.has(l.wallet_address)).sort((l,i)=>{const h=t.get(l.wallet_address)||0;return(t.get(i.wallet_address)||0)-h}),r=a.reduce((l,i)=>l+(t.get(i.wallet_address)||0),0);return{cluster_id:n.cluster_id,cluster_name:n.cluster_name,members:a,totalAmount:r,totalMembersInCluster:s.length}}).filter(n=>n.members.length>0).sort((n,s)=>s.totalAmount-n.totalAmount)}(function(){H();const t=B(),n=$(t.container,t.toggleBtn);t.toggleBtn.addEventListener("click",()=>{if(n.wasDragging())return;t.panel.style.display==="none"||t.panel.style.display===""?(t.panel.style.display="flex",t.content.innerText.includes("Click Refresh")&&w(t,!1)):t.panel.style.display="none"}),t.closeBtn.addEventListener("click",()=>{t.panel.style.display="none"}),t.refreshBtn.addEventListener("click",()=>{w(t,!1)}),t.deepAnalyzeBtn.addEventListener("click",()=>{w(t,!0)});let s=location.href;new MutationObserver(()=>{location.href!==s&&(s=location.href,console.log("[Cluster Scanner] URL changed, resetting..."),t.content.innerHTML='<div class="cs-loading">URL changed. Click Refresh.</div>',t.stats.innerHTML="")}).observe(document.body,{childList:!0,subtree:!0}),console.log("[Cluster Scanner] Ready!")})();
})()
