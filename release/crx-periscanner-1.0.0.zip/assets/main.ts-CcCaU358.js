(function(){console.log("[Cluster Scanner] Initializing...");const v="https://fibjnghzdogyhjzubokf.supabase.co/storage/v1/object/public/periscanner/clusters/periscanner_logo.png",y="https://scanner-api.periscannerx.workers.dev/api";function w(){const e=window.location.pathname,t=/[1-9A-HJ-NP-Za-km-z]{32,44}/,n=e.match(t);if(n)return console.log("[Cluster Scanner] Found address in path:",n[0]),n[0];const s=document.querySelector('iframe[src*="tokenAddress="]');if(s){const a=s.getAttribute("src");if(a){const o=a.match(/tokenAddress=([^&]+)/);if(o)return console.log("[Cluster Scanner] Found token in iframe:",o[1]),o[1]}}return null}async function L(e){const t=await fetch(`${y}/extension/scan-pair`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({urlTokenAddress:e})});if(!t.ok){const n=await t.json().catch(()=>({}));throw new Error(n.error||"Failed to scan pair")}return t.json()}async function S(e){const t=await fetch("https://fibjnghzdogyhjzubokf.supabase.co/functions/v1/scanner-api/get-cluster-by-wallets",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({wallets:e})});if(!t.ok)throw new Error("Failed to fetch clusters");return t.json()}function k(){const e=document.createElement("style");e.textContent=`
    #cluster-scanner-widget {
      position: fixed; 
      bottom: 20px;
      right: 20px;
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      touch-action: none;
      user-select: none; 
    }

    .cs-toggle {
      width: 56px;
      height: 56px;
      background: #1e293b;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: grab;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
      transition: transform 0.1s;
      border: 2px solid #334155;
      padding: 0;
      overflow: hidden;
    }

    .cs-toggle:active {
      cursor: grabbing;
      transform: scale(0.95);
    }

    .cs-toggle img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      pointer-events: none;
    }

    .cs-panel {
      position: absolute;
      bottom: 70px;
      right: 0;
      width: 380px;
      max-height: 600px;
      background: #0f172a;
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
      display: none;
      flex-direction: column;
      border: 1px solid #1e293b;
    }

    .cs-panel.visible { display: flex; }

    .cs-header {
      padding: 16px;
      background: #1e293b;
      border-bottom: 1px solid #334155;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .cs-header h3 { margin: 0; color: #60a5fa; font-size: 16px; font-weight: 600; }
    
    .cs-close {
      background: none; border: none; color: #94a3b8; font-size: 24px; cursor: pointer;
    }
    .cs-close:hover { color: white; }

    .cs-content { flex: 1; overflow-y: auto; padding: 16px; color: #e2e8f0; max-height: 400px; }
    
    .cs-loading { padding: 20px; text-align: center; color: #94a3b8; }
    .cs-error { background: #450a0a; color: #fca5a5; padding: 10px; border-radius: 6px; font-size: 13px; }
    .cs-empty { text-align: center; color: #64748b; padding: 20px; }
    
    .cs-cluster { margin-bottom: 12px; background: rgba(30, 41, 59, 0.3); border-radius: 8px; padding: 10px; border: 1px solid #334155; }
    .cs-cluster-header { display: flex; justify-content: space-between; margin-bottom: 8px; }
    .cs-cluster-name { font-weight: bold; color: #93c5fd; font-size: 13px; }
    .cs-member { display: flex; justify-content: space-between; font-size: 11px; padding: 4px 0; border-bottom: 1px solid rgba(255,255,255,0.05); }
    .cs-member-addr { font-family: monospace; color: #94a3b8; }
    
    .cs-refresh {
      margin: 10px; padding: 10px; background: #2563eb; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600;
    }
    .cs-refresh:disabled { opacity: 0.5; cursor: not-allowed; }

    /* Small badge for resolved mint */
    .cs-meta { font-size: 10px; color: #64748b; padding: 0 16px 8px; text-align: right; }
  `,document.head.appendChild(e)}function C(){const e=document.createElement("div");return e.id="cluster-scanner-widget",e.innerHTML=`
    <button id="cs-toggle" class="cs-toggle" title="Drag to move, click to toggle">
      <img src="${v}" alt="Scanner" />
    </button>
    <div id="cs-panel" class="cs-panel">
      <div class="cs-header">
        <h3>Cluster Scanner</h3>
        <button id="cs-close" class="cs-close">×</button>
      </div>
      <div id="cs-content" class="cs-content">
        <div class="cs-loading">Click Refresh to scan</div>
      </div>
      <div id="cs-meta" class="cs-meta"></div>
      <button id="cs-refresh" class="cs-refresh">Refresh Scan</button>
    </div>
  `,document.body.appendChild(e),{container:e,toggleBtn:e.querySelector("#cs-toggle"),panel:e.querySelector("#cs-panel"),closeBtn:e.querySelector("#cs-close"),content:e.querySelector("#cs-content"),meta:e.querySelector("#cs-meta"),refreshBtn:e.querySelector("#cs-refresh")}}function M(e,t){let n=!1,s=!1,a=0,o=0,u=0,g=0;t.addEventListener("pointerdown",f);function f(r){r.preventDefault(),t.setPointerCapture(r.pointerId);const c=e.getBoundingClientRect();e.style.bottom="auto",e.style.right="auto",e.style.left=`${c.left}px`,e.style.top=`${c.top}px`,a=r.clientX,o=r.clientY,u=c.left,g=c.top,n=!0,s=!1,t.addEventListener("pointermove",i),t.addEventListener("pointerup",l),t.addEventListener("pointercancel",l)}function i(r){if(!n)return;const c=r.clientX-a,d=r.clientY-o;(Math.abs(c)>3||Math.abs(d)>3)&&(s=!0);let p=u+c,m=g+d;const b=window.innerWidth-e.offsetWidth,x=window.innerHeight-e.offsetHeight;p=Math.max(0,Math.min(p,b)),m=Math.max(0,Math.min(m,x)),e.style.left=`${p}px`,e.style.top=`${m}px`}function l(r){n&&(n=!1,t.hasPointerCapture(r.pointerId)&&t.releasePointerCapture(r.pointerId),t.removeEventListener("pointermove",i),t.removeEventListener("pointerup",l),t.removeEventListener("pointercancel",l),setTimeout(()=>{s=!1},100))}return{wasDragging:()=>s}}async function h(e){const t=w();if(!t){e.content.innerHTML='<div class="cs-error">Could not find address in URL. Open a Pair or Token page.</div>';return}e.content.innerHTML='<div class="cs-loading">Resolving Pair & Scanning Holders...</div>',e.refreshBtn.disabled=!0;try{const s=(await L(t)).holders||[];if(s.length===0){e.content.innerHTML='<div class="cs-empty">No holders found.</div>';return}const a=s.map(i=>i.accountAddress),o=new Map(s.map(i=>[String(i.accountAddress),Number(i.humanReadableAmount)]));e.content.innerHTML=`<div class="cs-loading">Analyzing ${s.length} wallets for clusters...</div>`;const f=((await S(a)).clusters||[]).map(i=>{const l=i.members.filter(r=>o.has(r.wallet_address)).sort((r,c)=>{const d=o.get(r.wallet_address)||0;return(o.get(c.wallet_address)||0)-d});return{...i,members:l}}).filter(i=>i.members.length>0);T(e,f,o)}catch(n){console.error(n),e.content.innerHTML=`<div class="cs-error">${n instanceof Error?n.message:"Unknown Error"}</div>`}finally{e.refreshBtn.disabled=!1}}function T(e,t,n){if(t.length===0){e.content.innerHTML='<div class="cs-empty">No shared clusters found among top holders.</div>';return}const s=t.map(a=>`
    <div class="cs-cluster">
      <div class="cs-cluster-header">
        <span class="cs-cluster-name">${a.cluster_name||"Unnamed Cluster"}</span>
        <span style="font-size:10px; opacity:0.6">ID: ${a.cluster_id}</span>
      </div>
      <div>
        ${a.members.map(o=>`
          <div class="cs-member">
            <span class="cs-member-addr">${o.wallet_address.slice(0,4)}...${o.wallet_address.slice(-4)}</span>
            <span>${(n.get(o.wallet_address)||0).toLocaleString(void 0,{maximumFractionDigits:0})}</span>
          </div>
        `).join("")}
      </div>
    </div>
  `).join("");e.content.innerHTML=s}(function(){k();const t=C(),n=M(t.container,t.toggleBtn);t.toggleBtn.addEventListener("click",a=>{if(n.wasDragging())return;t.panel.style.display==="none"||t.panel.style.display===""?(t.panel.style.display="flex",t.content.innerText.includes("Click Refresh")&&h(t)):t.panel.style.display="none"}),t.closeBtn.addEventListener("click",()=>{t.panel.style.display="none"}),t.refreshBtn.addEventListener("click",()=>h(t));let s=location.href;new MutationObserver(()=>{location.href!==s&&(s=location.href,console.log("[Cluster Scanner] URL changed, resetting..."),t.content.innerHTML='<div class="cs-loading">URL changed. Click Refresh.</div>',t.meta.innerText="")}).observe(document.body,{childList:!0,subtree:!0}),console.log("[Cluster Scanner] Ready!")})();
})()
