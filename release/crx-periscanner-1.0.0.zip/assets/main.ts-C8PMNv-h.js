(function(){console.log("[Cluster Scanner] Initializing...");function T(){const e=document.querySelector('iframe[src*="tokenAddress="]');if(e){const s=e.getAttribute("src");if(s){const n=s.match(/tokenAddress=([^&]+)/);if(n){const a=n[1];return console.log("[Cluster Scanner] Extracted token from iframe:",a),a}}}const t=window.location.pathname.match(/\/meme\/([^\/\?]+)/);if(t){const s=t[1];return console.log("[Cluster Scanner] Extracted token from URL:",s),s}return null}async function B(e){const t=await fetch("https://fibjnghzdogyhjzubokf.supabase.co/functions/v1/scanner-api/get-token-top-holders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({mintAddress:e})});if(!t.ok)throw new Error("Failed to fetch holders");return t.json()}async function D(e){const t=await fetch("https://fibjnghzdogyhjzubokf.supabase.co/functions/v1/scanner-api/get-cluster-by-wallets",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({wallets:e})});if(!t.ok)throw new Error("Failed to fetch clusters");return t.json()}let c=!1,u=!1,i=0,d=0,m=0,g=0,v=0,w=0;function I(){const e=document.createElement("div");e.id="cluster-scanner-widget",e.innerHTML=`
    <div class="cs-toggle" id="cs-toggle">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10"/>
        <path d="M12 6v6l4 2"/>
      </svg>
    </div>
    <div class="cs-panel" id="cs-panel">
      <div class="cs-header">
        <h3>Cluster Scanner</h3>
        <button class="cs-close" id="cs-close">×</button>
      </div>
      <div class="cs-content" id="cs-content">
        <div class="cs-loading">Initializing...</div>
      </div>
      <button class="cs-refresh" id="cs-refresh">Refresh Scan</button>
    </div>
  `,document.body.appendChild(e);const t=document.createElement("style");return t.textContent=`
    #cluster-scanner-widget {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }

    .cs-toggle {
      width: 56px;
      height: 56px;
      background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: move;
      box-shadow: 0 4px 12px rgba(37, 99, 235, 0.4);
      transition: transform 0.2s, box-shadow 0.2s;
      color: white;
    }

    .cs-toggle:hover {
      transform: scale(1.05);
      box-shadow: 0 6px 16px rgba(37, 99, 235, 0.5);
    }

    .cs-toggle:active {
      transform: scale(0.95);
    }

    .cs-panel {
      position: absolute;
      bottom: 70px;
      right: 0;
      width: 380px;
      max-height: 600px;
      background: #0f172a;
      border-radius: 12px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5);
      display: none;
      flex-direction: column;
      overflow: hidden;
      border: 1px solid #1e293b;
    }

    .cs-panel.expanded {
      display: flex;
    }

    .cs-header {
      padding: 16px;
      background: #1e293b;
      border-bottom: 1px solid #334155;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .cs-header h3 {
      margin: 0;
      color: #60a5fa;
      font-size: 16px;
      font-weight: 600;
    }

    .cs-close {
      background: none;
      border: none;
      color: #94a3b8;
      font-size: 24px;
      cursor: pointer;
      padding: 0;
      width: 24px;
      height: 24px;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: color 0.2s;
    }

    .cs-close:hover {
      color: #f1f5f9;
    }

    .cs-content {
      flex: 1;
      overflow-y: auto;
      padding: 16px;
      color: #e2e8f0;
    }

    .cs-content::-webkit-scrollbar {
      width: 4px;
    }

    .cs-content::-webkit-scrollbar-track {
      background: transparent;
    }

    .cs-content::-webkit-scrollbar-thumb {
      background: #334155;
      border-radius: 10px;
    }

    .cs-loading {
      text-align: center;
      padding: 40px 20px;
      color: #94a3b8;
    }

    .cs-error {
      background: rgba(220, 38, 38, 0.1);
      border: 1px solid rgba(220, 38, 38, 0.3);
      padding: 12px;
      border-radius: 8px;
      color: #fca5a5;
      font-size: 14px;
    }

    .cs-empty {
      text-align: center;
      padding: 40px 20px;
      color: #64748b;
      font-style: italic;
    }

    .cs-cluster {
      margin-bottom: 16px;
    }

    .cs-cluster-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      margin-bottom: 8px;
    }

    .cs-cluster-name {
      font-size: 12px;
      font-weight: 600;
      color: #93c5fd;
      max-width: 200px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .cs-cluster-id {
      font-size: 9px;
      color: #64748b;
    }

    .cs-members {
      background: rgba(15, 23, 42, 0.5);
      border: 1px solid #1e293b;
      border-radius: 8px;
      overflow: hidden;
    }

    .cs-member {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 12px;
      border-bottom: 1px solid rgba(30, 41, 59, 0.5);
    }

    .cs-member:last-child {
      border-bottom: none;
    }

    .cs-member-address {
      font-family: 'Courier New', monospace;
      font-size: 10px;
      color: #94a3b8;
      max-width: 200px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .cs-member-amount {
      font-size: 12px;
      font-weight: 600;
      color: #e2e8f0;
    }

    .cs-refresh {
      margin: 12px 16px;
      padding: 10px;
      background: #2563eb;
      color: white;
      border: none;
      border-radius: 8px;
      font-weight: 600;
      font-size: 14px;
      cursor: pointer;
      transition: background 0.2s;
    }

    .cs-refresh:hover {
      background: #3b82f6;
    }

    .cs-refresh:disabled {
      opacity: 0.3;
      cursor: not-allowed;
    }

    .cs-refresh:disabled:hover {
      background: #2563eb;
    }
  `,document.head.appendChild(t),e}const A=I(),y=document.getElementById("cs-toggle"),k=document.getElementById("cs-panel"),H=document.getElementById("cs-close"),r=document.getElementById("cs-content"),l=document.getElementById("cs-refresh");y.addEventListener("click",e=>{e.stopPropagation(),u||(c=!c,k.classList.toggle("expanded",c),c&&!r.dataset.loaded&&b())});H.addEventListener("click",e=>{e.stopPropagation(),c=!1,k.classList.remove("expanded")});l.addEventListener("click",()=>{l.disabled||b()});y.addEventListener("mousedown",U);function U(e){m=e.clientX-v,g=e.clientY-w,u=!1,document.addEventListener("mousemove",E),document.addEventListener("mouseup",L)}function E(e){e.preventDefault(),i=e.clientX-m,d=e.clientY-g,(Math.abs(i)>5||Math.abs(d)>5)&&(u=!0),u&&(v=i,w=d,A.style.transform=`translate(${i}px, ${d}px)`)}function L(){m=i,g=d,document.removeEventListener("mousemove",E),document.removeEventListener("mouseup",L),setTimeout(()=>{u=!1},100)}async function b(){const e=T();if(!e){r.innerHTML='<div class="cs-empty">No token found in URL</div>';return}r.innerHTML='<div class="cs-loading">Analyzing clusters...</div>',r.dataset.loaded="true",l.disabled=!0;try{const s=(await B(e)).holders||[];if(s.length===0){r.innerHTML='<div class="cs-empty">No holders found</div>',l.disabled=!1;return}const n=s.map(o=>o.accountAddress),S=(await D(n)).clusters||[],p=new Map(s.map(o=>[o.accountAddress,o.humanReadableAmount])),z=new Set(n),C=S.map(o=>{const h=o.members.filter(f=>z.has(f.wallet_address)).sort((f,M)=>{const j=p.get(f.wallet_address)??0;return(p.get(M.wallet_address)??0)-j});return h.length>0?{...o,members:h}:null}).filter(o=>o!==null);$(C,p)}catch(t){r.innerHTML=`<div class="cs-error">Error: ${t instanceof Error?t.message:"Unknown error"}</div>`}finally{l.disabled=!1}}function $(e,t){if(e.length===0){r.innerHTML='<div class="cs-empty">No clusters found for these holders</div>';return}const s=e.map(n=>`
    <div class="cs-cluster">
      <div class="cs-cluster-header">
        <div class="cs-cluster-name">${n.cluster_name||"Unnamed Cluster"}</div>
        <div class="cs-cluster-id">ID: ${n.cluster_id}</div>
      </div>
      <div class="cs-members">
        ${n.members.map(a=>`
          <div class="cs-member">
            <div class="cs-member-address">${a.wallet_address}</div>
            <div class="cs-member-amount">
              ${(t.get(a.wallet_address)||0).toLocaleString(void 0,{maximumFractionDigits:2})}
            </div>
          </div>
        `).join("")}
      </div>
    </div>
  `).join("");r.innerHTML=s}let x=window.location.href;new MutationObserver(()=>{const e=window.location.href;e!==x&&(x=e,r.dataset.loaded="",c&&b())}).observe(document.body,{childList:!0,subtree:!0});console.log("[Cluster Scanner] Ready!");
})()
